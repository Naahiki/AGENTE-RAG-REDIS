// packages/crawler/src/types.ts
export type CrawlOutcome =
  | "UNCHANGED"
  | "SOFT_CHANGED"
  | "CHANGED"
  | "GONE"
  | "BLOCKED"
  | "ERROR";

export interface CrawlResult {
  outcome: CrawlOutcome;
  status?: number;
  etag?: string | null;
  lastModified?: string | null;
  rawHash?: string | null;
  contentBytes?: number | null;
  html?: string | null; // solo si cambia o lo pides
  error?: string | null;
  notes?: Record<string, any>;
}

export interface ScrapeResult {
  ok: boolean;
  textHash?: string | null;
  textLen?: number;
  fields?: Partial<{
    descripcion: string;
    documentacion: string;
    normativa: string;
    dirigido_a: string;
  }>;
  meta?: Record<string, any>;
  error?: string | null;
}

export interface EmbedResult {
  ok: boolean;
  dims?: number;
  error?: string | null;
  wroteHistory?: boolean;
  wrotePointer?: boolean;
}
