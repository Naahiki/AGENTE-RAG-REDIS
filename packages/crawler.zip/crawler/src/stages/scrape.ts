// packages/crawler/src/stages/scrape.ts
import { load } from "cheerio";
import { sha256 } from "../utils/hash";
import { db, schema } from "../db";
import { CFG } from "../config";
import type { ScrapeResult } from "../types";
import { eq } from "drizzle-orm";

/**
 * Extractor específico para páginas de navarra.es (selectores conocidos).
 * Si necesitas más reglas/dominos, crea nuevos extractores en este archivo
 * o en una carpeta /extractors y decide aquí cuál usar según el dominio.
 */
export function extractFieldsFromNavarra(html: string) {
  const $ = load(html);

  const getTxt = (sel: string) => ($(sel).first().text() || "").trim();

  const dirigido_a = getTxt("#infoDirigido > div:nth-child(1)");
  const descripcion = getTxt("#infoDescripcion > div:nth-child(1)");
  const documentacion = getTxt("#infoDocu > div:nth-child(1)");
  const normativa = getTxt("#infoNormativa > div:nth-child(1)");

  return { dirigido_a, descripcion, documentacion, normativa };
}

/**
 * Scrapea una ayuda concreta a partir del HTML.
 * - Calcula un text_hash (hash del texto útil) para decidir si hay cambio semántico.
 * - Si hay cambio, actualiza campos en `ayudas` y aumenta `content_version`.
 * - Audita en `scrape_audit` si SCRAPE_AUDIT_ENABLED=1.
 */
export async function scrapeOne(ayuda: any, html: string): Promise<ScrapeResult> {
  try {
    // 1) Extrae campos con el extractor de navarra
    const fields = extractFieldsFromNavarra(html);

    // 2) Concatena texto útil para hash y umbral mínimo
    const concat = [
      fields.descripcion,
      fields.documentacion,
      fields.normativa,
      fields.dirigido_a,
    ]
      .filter(Boolean)
      .join("\n\n");

    const textLen = concat.length;

    // 3) Umbral de sanidad: evita guardar ruido o páginas sin contenido
    if (textLen < CFG.SCRAPER_MIN_TEXT_LEN) {
      await audit(ayuda.id, ayuda.url_oficial, {
        ok: false,
        textLen,
        textHash: null,
        extractor: "rules(navarra.es)",
        meta: { reason: "too_short" },
      });
      return {
        ok: false,
        textLen,
        textHash: null,
        fields,
        meta: { reason: "too_short" },
      };
    }

    // 4) Calcula hash del texto útil y decide si ha cambiado
    const textHash = sha256(concat);
    const changed = !ayuda.text_hash || ayuda.text_hash !== textHash;

    // 5) Persistencia en ayudas: solo toco contenido/versionado si hay cambio semántico
    if (changed) {
      await db
        .update(schema.ayudas)
        .set({
          dirigido_a: fields.dirigido_a || ayuda.dirigido_a,
          descripcion: fields.descripcion || ayuda.descripcion,
          documentacion: fields.documentacion || ayuda.documentacion,
          normativa: fields.normativa || ayuda.normativa,
          text_hash: textHash,
          content_version: (ayuda.content_version ?? 0) + 1,
          last_scraped_at: new Date(),
          last_scrape_ok: true,
          last_error: null,
          updated_at: new Date(),
        })
        .where(eq(schema.ayudas.id, ayuda.id));
    } else {
      // No cambió el texto útil: solo marco la corrida y OK
      await db
        .update(schema.ayudas)
        .set({
          last_scraped_at: new Date(),
          last_scrape_ok: true,
          last_error: null,
        })
        .where(eq(schema.ayudas.id, ayuda.id));
    }

    // 6) Auditoría
    await audit(ayuda.id, ayuda.url_oficial, {
      ok: true,
      textLen,
      textHash,
      extractor: "rules(navarra.es)",
      meta: { changed },
    });

    return { ok: true, textLen, textHash, fields, meta: { changed } };
  } catch (e: any) {
    // 7) Marca error en ayudas + auditoría
    await db
      .update(schema.ayudas)
      .set({
        last_scraped_at: new Date(),
        last_scrape_ok: false,
        last_error: e?.message || String(e),
      })
      .where(eq(schema.ayudas.id, ayuda.id));

    await audit(ayuda.id, ayuda.url_oficial, {
      ok: false,
      textLen: 0,
      textHash: null,
      extractor: "rules(navarra.es)",
      meta: null,
      error: e?.message || String(e),
    });

    return { ok: false, error: e?.message || String(e) };
  }
}

// --- Auditoría interna ---
async function audit(
  ayuda_id: number,
  url: string,
  data: {
    ok: boolean;
    textLen: number | null;
    textHash: string | null;
    extractor: string;
    meta?: Record<string, any> | null;
    error?: string | null;
  }
) {
  if (!CFG.SCRAPE_AUDIT_ENABLED) return;
  await db.insert(schema.scrapeAudit).values({
    ayuda_id,
    url,
    ts: new Date(),
    extractor: data.extractor,
    text_hash: data.textHash,
    text_len: data.textLen ?? null,
    lang: null,
    meta: data.meta ?? null,
    error: data.error ?? null,
  });
}
