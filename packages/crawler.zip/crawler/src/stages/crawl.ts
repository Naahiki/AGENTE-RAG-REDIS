import { db, schema } from "../db";
import { CFG } from "../config";
import { normalizeHtml } from "../utils/html";
import { sha256 } from "../utils/hash";
import { allowedByRobots } from "../utils/robots";
import type { CrawlResult } from "../types";
import { eq } from "drizzle-orm";

/** 🔒 DRY-RUN global: si está activo, NO se escribe nada en BD */
const DRY_RUN = process.env.CRAWLER_DRY_RUN === "1";

/** Helpers SEGUROS: nunca escriben si DRY_RUN */
async function safeUpsertAyuda(id: number, patch: Record<string, any>) {
  if (DRY_RUN) return; // 🛑 no escribir en dry-run
  await db.update(schema.ayudas).set(patch).where(eq(schema.ayudas.id, id));
}

async function safeAudit(
  outcome: "UNCHANGED" | "SOFT_CHANGED" | "CHANGED" | "GONE" | "BLOCKED" | "ERROR",
  ayuda_id: number,
  url: string,
  extra: Record<string, any> = {}
) {
  if (!CFG.CRAWL_AUDIT_ENABLED) return;
  if (DRY_RUN) return; // 🛑 no auditar en dry-run
  await db.insert(schema.crawlAudit).values({
    ayuda_id,
    url,
    ts: new Date(),
    http_status: extra.http_status ?? null,
    duration_ms: extra.duration_ms ?? null,
    etag: extra.etag ?? null,
    last_modified: extra.last_modified ?? null,
    raw_hash: extra.raw_hash ?? null,
    diff_score: extra.diff_score ?? null,
    outcome,
    content_bytes: extra.content_bytes ?? null,
    notes: extra.notes ?? null,
    error: extra.error ?? null,
  });
}

/**
 * CRAWL una ayuda (descarga HTML y detecta cambios con ETag/Last-Modified y hash del HTML normalizado).
 */
export async function crawlOne(ayuda: any): Promise<CrawlResult> {
  const url = ayuda?.url_oficial?.trim();
  if (!url) return { outcome: "ERROR", error: "sin url_oficial" };

  // Respeta robots.txt (opcional)
  if (CFG.CRAWLER_OBEY_ROBOTS) {
    const ok = await allowedByRobots(url, CFG.CRAWLER_USER_AGENT);
    if (!ok) {
      // 👇 en dry-run NO audites
      await safeAudit("BLOCKED", ayuda.id, url, { notes: { robots: "disallow" } });
      return { outcome: "BLOCKED" };
    }
  }

  let status = 0;
  let etag: string | null = null;
  let lastModified: string | null = null;
  let contentBytes: number | null = null;

  const headers: Record<string, string> = { "User-Agent": CFG.CRAWLER_USER_AGENT };
  if (ayuda.etag) headers["If-None-Match"] = ayuda.etag;
  if (ayuda.last_modified) headers["If-Modified-Since"] = ayuda.last_modified;

  const started = Date.now();
  let error: string | null = null;

  for (let attempt = 0; attempt <= CFG.CRAWLER_RETRY; attempt++) {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), CFG.CRAWLER_TIMEOUT_MS);

      const res = await fetch(url, { headers, redirect: "follow", signal: ctrl.signal });
      clearTimeout(to);

      status = res.status;
      etag = res.headers.get("etag");
      lastModified = res.headers.get("last-modified");

      // 304 Not Modified
      if (status === 304) {
        await safeUpsertAyuda(ayuda.id, {
          etag,
          last_modified: lastModified,
          last_crawled_at: new Date(),
          last_crawl_outcome: "UNCHANGED",
          last_error: null,
        });
        await safeAudit("UNCHANGED", ayuda.id, url, {
          http_status: status,
          etag,
          last_modified: lastModified,
          duration_ms: Date.now() - started,
        });
        return { outcome: "UNCHANGED", status };
      }

      // 2xx — descarga y calcula hash
      if (status >= 200 && status < 300) {
        const html = await res.text();
        contentBytes = html.length;

        const base = CFG.SCRAPER_NORMALIZE_HTML ? normalizeHtml(html) : html;
        const rawHash = sha256(base);

        const unchanged = ayuda.raw_hash && ayuda.raw_hash === rawHash;
        const outcome = unchanged ? "UNCHANGED" : "CHANGED";

        await safeUpsertAyuda(ayuda.id, {
          etag,
          last_modified: lastModified,
          content_bytes: contentBytes,
          raw_hash: rawHash,
          last_crawled_at: new Date(),
          last_crawl_outcome: outcome,
          last_error: null,
        });

        await safeAudit(outcome, ayuda.id, url, {
          http_status: status,
          etag,
          last_modified: lastModified,
          raw_hash: rawHash,
          content_bytes: contentBytes,
          duration_ms: Date.now() - started,
        });

        return {
          outcome,
          status,
          etag,
          lastModified,
          rawHash,
          contentBytes,
          html: unchanged ? null : html,
        };
      }

      // 404/410 => GONE
      if (status === 404 || status === 410) {
        await safeUpsertAyuda(ayuda.id, {
          last_crawled_at: new Date(),
          last_crawl_outcome: "GONE",
          last_error: null,
        });
        await safeAudit("GONE", ayuda.id, url, {
          http_status: status,
          duration_ms: Date.now() - started,
        });
        return { outcome: "GONE", status };
      }

      // Otros estados HTTP
      error = `HTTP ${status}`;
    } catch (e: any) {
      error = `fetch error: ${e?.message || e}`;
    }

    // Backoff/reintento
    if (attempt < CFG.CRAWLER_RETRY) {
      await new Promise((r) => setTimeout(r, CFG.CRAWLER_BACKOFF_MS));
    }
  }

  // Fallo definitivo
  await safeUpsertAyuda(ayuda.id, {
    last_crawled_at: new Date(),
    last_crawl_outcome: "ERROR",
    last_error: error,
  });
  await safeAudit("ERROR", ayuda.id, url, {
    http_status: status,
    error,
    duration_ms: Date.now() - started,
  });
  return { outcome: "ERROR", status, error };
}
