#!/usr/bin/env tsx
/**
 * Dry-run del pipeline PARA UNA AYUDA usando solo URL (sin tocar BD).
 * - Evita dependencias de 'minimist' y choques de tipos Drizzle.
 * - No escribe nada (dry-run conceptual).
 *
 * Uso:
 *   pnpm pipeline:one --url=https://... [--scrape] [--embed] [--log=debug]
 *   pnpm pipeline:one --id=UUID   (avisará y seguirá en modo fake si no hay URL)
 */

import * as dotenv from "dotenv";
dotenv.config();

import { parseArgs } from "node:util";
import { crawlOne } from "../src/stages/crawl";
import { scrapeOne } from "../src/stages/scrape";
import { embedOne } from "../src/stages/embed";

// 🔐 util para imprimir propiedades si existen en el objeto
function printIf<T extends object>(obj: T, key: string, label?: string) {
  if (obj && key in obj) {
    const val = obj[key];
    const k = label ?? key;
    if (typeof val === "string" || typeof val === "number" || typeof val === "boolean") {
      console.log(`${k}:`, val);
    } else if (Array.isArray(val)) {
      console.log(`${k} (#):`, val.length);
      if (val.length && typeof val[0] === "string") {
        console.log(`${k} (sample):`, val.slice(0, 5));
      }
    } else if (val && typeof val === "object") {
      console.log(`${k} (keys):`, Object.keys(val));
    } else {
      console.log(`${k}:`, val);
    }
  }
}

type Args = {
  id?: string;
  url?: string;
  scrape?: boolean;
  embed?: boolean;
  log?: "debug" | "info";
};

async function main() {
  const {
    values,
  } = parseArgs({
    options: {
      id: { type: "string" },
      url: { type: "string" },
      scrape: { type: "boolean", default: true },
      embed: { type: "boolean", default: false },
      log: { type: "string", default: "info" },
    },
    allowPositionals: false,
  });

  const args: Args = {
    id: values.id as string | undefined,
    url: values.url as string | undefined,
    scrape: Boolean(values.scrape),
    embed: Boolean(values.embed),
    log: (values.log as "debug" | "info") ?? "info",
  };

  if (!args.url && args.id) {
    console.warn(
      "[pipeline:one] Se pasó --id pero este script de dry-run evita la BD mientras hay conflicto de Drizzle. " +
      "Pasa --url para operar en fake sin writes."
    );
  }

  if (!args.url) {
    console.error("Uso: pnpm pipeline:one --url=<URL> [--scrape] [--embed] [--log=debug]");
    process.exit(1);
  }

  // Ayuda "fake" para no tocar BD:
  const ayuda = {
    id: "dry-" + Date.now(),
    url_oficial: args.url,
    nombre: "DRY ONE-OFF",
  } as const;

  if (args.log === "debug") {
    console.log("[info] args:", args);
    console.log("[info] ayuda:", ayuda);
  }

  console.log(`[crawl] ${ayuda.url_oficial}`);
  const c = await crawlOne(ayuda as any); // tu firma real: 1 arg

  printIf(c as any, "outcome");
  printIf(c as any, "status");
  printIf(c as any, "rawHash");
  printIf(c as any, "hash");
  printIf(c as any, "etag");
  printIf(c as any, "lastModified");
  printIf(c as any, "fetchedAt");
  printIf(c as any, "title");
  printIf(c as any, "links");
  printIf(c as any, "warnings");

  const hasHtml = "html" in (c as any) && typeof (c as any).html === "string" && (c as any).html.length > 0;
  console.log("html?:", hasHtml);

  if (hasHtml && args.scrape) {
    console.log("[scrape] …");
    const html: string = (c as any).html;
    const s = await scrapeOne(ayuda as any, html); // tu firma real: 2 args

    printIf(s as any, "text");
    printIf(s as any, "text_hash");
    printIf(s as any, "textHash");
    printIf(s as any, "fields");
    printIf(s as any, "data");
    printIf(s as any, "sections");

    if (s && "text" in (s as any) && typeof (s as any).text === "string") {
      const t = (s as any).text as string;
      console.log("[scrape] text length:", t.length);
      console.log("[scrape] text preview:\n", t.slice(0, 400));
    }

    if (args.embed) {
      console.log("[embed] (dry-run conceptual) …");
      // No escribimos nada; si tu embedOne requiere 1 arg, se lo pasamos tal cual:
      await embedOne({ ...(ayuda as any), textHash: (s as any)?.textHash ?? (s as any)?.text_hash ?? null } as any);
    }
  } else {
    console.log("[scrape] omitido (sin HTML o --scrape=false)");
  }

  console.log("[pipeline:one] done (dry-run)");
}

main().catch((e) => {
  console.error("[pipeline:one] error:", e);
  process.exit(1);
});
