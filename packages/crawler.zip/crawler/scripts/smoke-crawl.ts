#!/usr/bin/env tsx
/**
 * Smoke test compatible con las firmas y tipos reales:
 * - crawlOne(ayuda)              // 1 arg
 * - scrapeOne(ayuda, html)       // 2 args
 *
 * Forzamos DRY-RUN desde el script y usamos id numérico para evitar conflictos con BD.
 *
 * Uso:
 *   pnpm crawl:smoke https://www.navarra.es/es/tramites/on/-/line/ayuda-x
 */

// 👇 fuerza dry-run para que los stages (si lo soportan) no escriban en BD
process.env.CRAWLER_DRY_RUN = process.env.CRAWLER_DRY_RUN ?? "1";

import * as dotenv from "dotenv";
dotenv.config();

import { crawlOne } from "../src/stages/crawl";
import { scrapeOne } from "../src/stages/scrape";

type FakeAyuda = {
  id: number; // 👈 tu columna es integer
  nombre?: string | null;
  url_oficial: string | null;
  rawHash?: string | null;
  etag?: string | null;
  last_crawled_at?: string | null;
  last_scraped_at?: string | null;
  text_hash?: string | null;
};

function printIf<T extends object>(obj: T, key: string, label?: string) {
  if (obj && key in obj) {
    const k = label ?? key;
    const val = obj[key];
    if (typeof val === "string" || typeof val === "number" || typeof val === "boolean") {
      console.log(`${k}:`, val);
    } else if (Array.isArray(val)) {
      console.log(`${k} (#):`, val.length);
      if (val.length && typeof val[0] === "string") {
        console.log(`${k} (sample):`, val.slice(0, 5));
      }
    } else if (val && typeof val === "object") {
      console.log(`${k} (keys):`, Object.keys(val));
    } else {
      console.log(`${k}:`, val);
    }
  }
}

async function main() {
  const url = process.argv[2];
  if (!url) {
    console.error("Uso: pnpm crawl:smoke <URL>");
    process.exit(1);
  }

  const ayuda: FakeAyuda = {
    id: -1, // 👈 número “dummy” para evitar errores de tipo
    url_oficial: url,
    nombre: "SMOKE TEST",
  };

  console.log("[smoke] crawling:", url);
  const crawl = await crawlOne(ayuda as any);

  printIf(crawl as any, "outcome");
  printIf(crawl as any, "status");
  printIf(crawl as any, "rawHash");
  printIf(crawl as any, "hash");
  printIf(crawl as any, "etag");
  printIf(crawl as any, "lastModified");
  printIf(crawl as any, "fetchedAt");
  printIf(crawl as any, "title");
  printIf(crawl as any, "links");
  printIf(crawl as any, "warnings");

  const hasHtml =
    "html" in (crawl as any) &&
    typeof (crawl as any).html === "string" &&
    (crawl as any).html.length > 0;

  console.log("html?:", hasHtml);

  if (hasHtml) {
    console.log("\n[smoke] scraping…");
    const html: string = (crawl as any).html;
    const scraped = await scrapeOne(ayuda as any, html);

    printIf(scraped as any, "text");
    printIf(scraped as any, "text_hash");
    printIf(scraped as any, "textHash");
    printIf(scraped as any, "fields");
    printIf(scraped as any, "data");
    printIf(scraped as any, "sections");

    if (scraped && "text" in (scraped as any) && typeof (scraped as any).text === "string") {
      const t = (scraped as any).text as string;
      console.log("\n[smoke] text length:", t.length);
      console.log("[smoke] text preview:\n", t.slice(0, 400));
    }
  } else {
    console.log("[smoke] no HTML. Scrape omitido.");
  }
}

main().catch((e) => {
  console.error("[smoke] error:", e);
  process.exit(1);
});
